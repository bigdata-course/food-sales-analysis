$(document).ready(function(){
	$("a#set").click(function(){
		$("#keywordform").toggle();
		$("#tagform").toggle();
	});
});